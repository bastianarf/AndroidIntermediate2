package com.bastian.storyapps.data.model

data class UserModel(
    val name: String,
    val token: String,
    val isLogin: Boolean
)